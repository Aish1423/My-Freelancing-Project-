const mongoose = require('mongoose')

const categorySchema = new mongoose.Scheme({
    id:{type : Number, default:0},
    clientID:{type : Number, default:0},
    autoID:{type : Number, default:0},
    name:{type : String, default:""},
    thumbnail:{type : String, default:""},
    createdAt:{type : Date, default:Date.now()},
    status:{type : Boolean, default:true},
 
})
module.exports=mongoose.model("category", categorySchema)