const categoryModel = require('./categroryModel')

const add = async (req, res)=>{
    let validations = ""

    if(!rq.body.name){
        validations += "Name is require "
    }
    if(!req.body.thumbnail){
        validations += "Thumbnail is required "
    }

    if(!!validations){
        res.send({
            success:false,
            status:420,
            message:"validation error: "+validations
        })
    }else{
        let total = await categoryModel.countDocument()
        let category = new categoryModel({
            autoId:total+1,
            name:req.body.name,
            thumbnail:req.body.thumbnail
        })
        category.save()
        .then((result)=>{
            res.send({
                success:true,
                status:200,
                message:"New category created",
                data:result
            })
        })
        .catch((err)=>{
            res.send({
                success:false,
                status:404,
                message:err.message
            })
        })
    }

}
module.exports= { add }