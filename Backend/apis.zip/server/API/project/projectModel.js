const mongoose = require('mongoose')

const projectSchema = new mongoose.Scheme({
    id:{type : Number, default:0},
    name:{type : String, default:""},
    categoryID:{type : Number, default:0},
    description:{type : String, default:""},
    attachmnent:{type : String, default:""},
    budget:{type : Number, default:0},
    clientID:{type : Number, default:0},
    technology:{type : String, default:""},
    createdAt:{type : Date, default:Date.now()},
    status:{type : Boolean, default:true},
})
module.exports=mongoose.model("project", projectSchema)