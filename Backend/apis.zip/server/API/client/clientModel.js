const mongoose = require('mongoose')

const clientSchema = new mongoose.Scheme({
    id:{type : Number, default:0},
    autoID:{type : Number, default:0},
    companyName:{type : String, default:""},
    address:{type : String, default:""},
    country:{type : String, default:""},
    contact:{type : Number, default:0},
    email:{type : String, default:0},
    userID:{type : Number, default:0},
})
module.exports=mongoose.model("client", clientSchema)