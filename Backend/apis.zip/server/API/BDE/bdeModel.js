const mongoose = require('mongoose')

const bdeSchema = new mongoose.Scheme({
    id:{type : Number, default:0},
    autoID:{type : Number, default:0},
    name:{type : String, default:""},
    email:{type : String, default:""},
    password:{type : String, default:""},
    contact:{type : Number, default:0},
    preferenceID:{type : Number, default:0},
    userID:{type : Number, default:""},
})
module.exports=mongoose.model("BDE", bdeSchema)