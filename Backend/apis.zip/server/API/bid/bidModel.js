const mongoose = require('mongoose')

const bidSchema = new mongoose.Scheme({
    id:{type : Number, default:0},
    clientID:{type : Number, default:0},
    projectID:{type : Number, default:0},
    bdeID:{type : Number, default:0},
    poc:{type : String, default:""},
    bids:{type : String, default:""},
    duration:{type : String, default:""},
    createdAt:{type : Date, default:Date.now()},
    status:{type : Boolean, default:true},
    
})
module.exports=mongoose.model("bid", bidSchema)